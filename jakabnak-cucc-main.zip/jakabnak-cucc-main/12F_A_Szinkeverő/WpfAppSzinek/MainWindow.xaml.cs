﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppSzinek
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void addToList(object sender, MouseButtonEventArgs e)
        {
            byte red = (byte)sliRed.Value;
            lbRed.Content = red.ToString();

            byte green = (byte)sliGreen.Value;
            lbGreen.Content = green.ToString();

            byte blue = (byte)sliBlue.Value;
            lbBlue.Content = blue.ToString();

            string szinFuggveny = $"RGB({red},{green},{blue})";
            lbSzinek.Items.Add(szinFuggveny);

        }

        private void sliChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red = (byte)sliRed.Value;
            lbRed.Content = red.ToString();

            byte green = (byte)sliGreen.Value;
            lbGreen.Content = green.ToString();

            byte blue = (byte)sliBlue.Value;
            lbBlue.Content = blue.ToString();

            SolidColorBrush ujSzin = new SolidColorBrush(Color.FromRgb(red, green, blue));

            ellipseSample.Fill = ujSzin;
        }

        private void colorChange(object sender, SelectionChangedEventArgs e)
        {
            if (lbSzinek.SelectedIndex == -1)
                return;

            string szinFuggveny = lbSzinek.Items[lbSzinek.SelectedIndex].ToString()!;
            szinFuggveny = szinFuggveny.Substring(4, szinFuggveny.Length - 5);
            var szinek = szinFuggveny.Split(",");
            sliRed.Value = Double.Parse(szinek[0]);
            sliGreen.Value = Double.Parse(szinek[1]);
            sliBlue.Value = Double.Parse(szinek[2]);
        }


    }
}