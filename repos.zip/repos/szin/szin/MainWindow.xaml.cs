﻿using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace szin
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSzamol_Click(object sender, RoutedEventArgs e)
        {

            if (rdoOsszeadas.IsChecked == true)
            {
                labEredmeny.Content = Double.Parse(txtAszam.Text) + Double.Parse(txtBszam.Text);

            }
            else if (rdoKivonas.IsChecked == true)
            { labEredmeny.Content = Double.Parse(txtAszam.Text) - Double.Parse(txtBszam.Text);
            }
            else if (rdoSzorzas.IsChecked == true)
            {
                labEredmeny.Content = Double.Parse(txtAszam.Text) * Double.Parse(txtBszam.Text);
            }
            else if (rdoOsztas.IsChecked == true)
            {

                if (Double.Parse(txtBszam.Text) == 0 )
                { MessageBox.Show("Nem lehet nullával osztani!");
                    return;
                }
            labEredmeny.Content = Double.Parse(txtAszam.Text) / Double.Parse(txtBszam.Text);
            }

            }
        
        private void btnSzamol_MouseEnter(object sender, MouseEventArgs e)
        {
            txtAszam.Background = new SolidColorBrush(Colors.AliceBlue);
        }

        private void txtAszam_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                Convert.ToDouble(txtAszam.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Figyelem! Hibás formátum.");
                txtAszam.Text = "0";
            }
            
        }

        private void txtAszam_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtAszam_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
    }
}